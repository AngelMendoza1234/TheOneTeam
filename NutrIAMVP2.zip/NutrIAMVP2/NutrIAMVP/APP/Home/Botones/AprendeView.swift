//
//  AprendeView.swift
//  NutrIAMVP
//
//  Created by Samuel Alarcón on 08/06/25.
//


//
//  AprendeView.swift
//  NutrIA
//
//  Created by Alumno on 08/06/25.

import SwiftUI
import AVFoundation
import WebKit

struct AprendeView: View {
    @State private var currentQuestionIndex = 0
    @State private var showFeedback = false
    @State private var isCorrect = false
    @State private var feedbackText = ""
    @State private var player: AVAudioPlayer?

    let quizPreguntas: [(pregunta: String, respuesta: Bool, explicacion: String)] = [
        ("La glucosa es una fuente de energía para el cuerpo.", true, "¡Sí! La glucosa es la principal fuente de energía para nuestras células."),
        ("La insulina evita que la glucosa entre en las células.", false, "No, la insulina ayuda a que la glucosa entre a las células."),
        ("Hacer ejercicio puede ayudar a controlar la glucosa.", true, "¡Correcto! El ejercicio ayuda a usar la glucosa como energía y a mantener niveles saludables."),
    ]

    var body: some View {
        NavigationView {
            GeometryReader { geo in
                ZStack {
                    Color.white.ignoresSafeArea()

                    VStack(spacing: 0) {
                        ZStack {
                            Color("cielo")
                                .ignoresSafeArea(edges: .top)
                                .frame(height: geo.size.height * 0.15)

                            HStack {
                                Image("aprende")
                                    .resizable()
                                    .frame(width: geo.size.width * 0.12, height: geo.size.width * 0.12)

                                Spacer()

                                Text("Aprende +")
                                    .font(.system(size: geo.size.width * 0.12, weight: .bold))
                                    .foregroundColor(Color("aqua"))

                                Spacer()
                            }
                            .padding(.horizontal)
                            .padding(.top, geo.safeAreaInsets.top)
                            .padding(.bottom, 50)
                        }
                        .frame(height: geo.size.height * 0.13)
                        .padding(.bottom, 20)

                        ScrollView {
                            VStack(spacing: 20) {
                                Text("¿Qué es la glucosa?")
                                    .font(.system(size: geo.size.width * 0.055, weight: .bold))
                                    .foregroundColor(Color("aqua"))
                                    .multilineTextAlignment(.center)

                                HStack(alignment: .top, spacing: 5) {
                                    Image("gota")
                                        .resizable()
                                        .frame(width: geo.size.width * 0.23, height: geo.size.width * 0.23)

                                    Text("La glucosa es el azúcar que el cuerpo usa como energía. Viene de los alimentos que comemos, como frutas, pan o arroz. Viaja por la sangre y entra a las células para que el cuerpo pueda moverse, pensar y vivir.")
                                        .font(.system(size: geo.size.width * 0.04))
                                }
                                .padding()
                                .background(Color("cielo"))
                                .cornerRadius(15)

                                VStack(spacing: 10) {
                                    HStack(spacing: 12) {
                                        Text("¿Qué es la insulina?")
                                            .multilineTextAlignment(.center)
                                        Text("¿Qué pasa si la glucosa no entra a las células?")
                                            .multilineTextAlignment(.center)
                                    }
                                    .font(.system(size: geo.size.width * 0.045, weight: .semibold))
                                    .foregroundColor(Color("aqua"))

                                    HStack(spacing: 12) {
                                        Text("Es una sustancia que produce el cuerpo y ayuda a que la glucosa entre en las células. Es como una llave.")
                                            .font(.system(size: geo.size.width * 0.037))
                                            .padding(10)
                                            .background(Color("cielo"))
                                            .cornerRadius(15)
                                            .frame(maxWidth: .infinity)

                                        Text("Si la glucosa se queda en la sangre y no entra a las células, el cuerpo puede sentirse cansado o enfermo.")
                                            .font(.system(size: geo.size.width * 0.037))
                                            .padding(10)
                                            .background(Color("cielo"))
                                            .cornerRadius(15)
                                            .frame(maxWidth: .infinity)
                                    }
                                }

                                VStack(spacing: 14) {
                                    Text("¿Cómo cuidar la glucosa?")
                                        .font(.system(size: geo.size.width * 0.05, weight: .bold))
                                        .foregroundColor(Color("aqua"))

                                    HStack(spacing: 20) {
                                        cuidadoItem(nombre: "sano", texto: "come bien", size: geo.size.width * 0.19)
                                        cuidadoItem(nombre: "duerme", texto: "duerme tus horas", size: geo.size.width * 0.19)
                                        cuidadoItem(nombre: "ejercicio", texto: "ejercita tu cuerpo", size: geo.size.width * 0.19)
                                    }
                                }

                                VStack(alignment: .leading, spacing: 16) {
                                    Text("Videos para aprender más")
                                        .font(.system(size: geo.size.width * 0.05, weight: .bold))
                                        .foregroundColor(Color("aqua"))

                                    videoCard(titulo: "¿Qué es la resistencia a la insulina?", descripcion: "Un video que explica cómo funciona la insulina y qué pasa cuando el cuerpo no la usa bien.", url: "https://www.youtube.com/embed/X0IWgVsN4y4", geo: geo)

                                    videoCard(titulo: "¿Qué es la diabetes?", descripcion: "Descubre cómo afecta la diabetes al cuerpo y qué hacer para cuidarte.", url: "https://www.youtube.com/embed/IYJNTVLyRrs", geo: geo)
                                }

                                // Juego integrado
                                VStack(spacing: 20) {
                                    Text("Juego: ¿Verdadero o Falso?")
                                        .font(.title2)
                                        .bold()
                                        .foregroundColor(.purple)

                                    Text("Lee la frase y responde si es verdadera o falsa. ¡Aprende jugando!")
                                        .multilineTextAlignment(.center)
                                        .foregroundColor(.gray)

                                    VStack(spacing: 12) {
                                        Text(quizPreguntas[currentQuestionIndex].pregunta)
                                            .font(.headline)
                                            .multilineTextAlignment(.center)
                                            .padding()
                                            .background(Color.yellow.opacity(0.2))
                                            .cornerRadius(10)

                                        HStack(spacing: 30) {
                                            Button(action: {
                                                responder(eleccion: true)
                                            }) {
                                                Text("Verdadero")
                                                    .foregroundColor(.white)
                                                    .padding()
                                                    .frame(width: 120)
                                                    .background(Color.green)
                                                    .cornerRadius(10)
                                            }

                                            Button(action: {
                                                responder(eleccion: false)
                                            }) {
                                                Text("Falso")
                                                    .foregroundColor(.white)
                                                    .padding()
                                                    .frame(width: 120)
                                                    .background(Color.red)
                                                    .cornerRadius(10)
                                            }
                                        }

                                        if showFeedback {
                                            VStack(spacing: 10) {
                                                Text(isCorrect ? "¡Correcto!" : "Incorrecto")
                                                    .font(.title3)
                                                    .bold()
                                                    .foregroundColor(isCorrect ? .green : .red)

                                                Text(feedbackText)
                                                    .foregroundColor(.black)
                                                    .multilineTextAlignment(.center)

                                                Button("Siguiente") {
                                                    siguientePregunta()
                                                }
                                                .padding(8)
                                                .background(Color("aqua"))
                                                .foregroundColor(.white)
                                                .cornerRadius(8)
                                            }
                                            .padding()
                                            .background(Color.white)
                                            .cornerRadius(12)
                                            .shadow(radius: 4)
                                        }
                                    }
                                    .padding()
                                    .background(Color.blue.opacity(0.05))
                                    .cornerRadius(15)
                                }
                            }
                            .padding(.horizontal)
                            .padding(.bottom, 20)
                        }

                        
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }

    func responder(eleccion: Bool) {
        let correcta = quizPreguntas[currentQuestionIndex].respuesta
        isCorrect = eleccion == correcta
        feedbackText = quizPreguntas[currentQuestionIndex].explicacion
        showFeedback = true
        playSound(correct: isCorrect)
    }

    func siguientePregunta() {
        if currentQuestionIndex < quizPreguntas.count - 1 {
            currentQuestionIndex += 1
            showFeedback = false
        } else {
            currentQuestionIndex = 0
            showFeedback = false
        }
    }

    func playSound(correct: Bool) {
        let fileName = correct ? "correct" : "wrong"
        if let url = Bundle.main.url(forResource: fileName, withExtension: "mp3") {
            player = try? AVAudioPlayer(contentsOf: url)
            player?.play()
        }
    }

    func videoCard(titulo: String, descripcion: String, url: String, geo: GeometryProxy) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(titulo)
                .font(.system(size: geo.size.width * 0.045, weight: .semibold))
                .foregroundColor(.primary)

            Text(descripcion)
                .font(.system(size: geo.size.width * 0.035))
                .foregroundColor(.gray)

            VideoView(videoURL: url)
                .frame(height: geo.size.width * 0.55)
                .cornerRadius(10)
        }
    }

    func cuidadoItem(nombre: String, texto: String, size: CGFloat) -> some View {
        VStack(spacing: 6) {
            Circle()
                .fill(Color("cielo"))
                .frame(width: size + 20, height: size + 20)
                .overlay(
                    Image(nombre)
                        .resizable()
                        .scaledToFit()
                        .frame(width: size, height: size)
                )
            Text(texto)
                .font(.caption)
                .multilineTextAlignment(.center)
        }
    }
}

struct VideoView: UIViewRepresentable {
    let videoURL: String

    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        guard let url = URL(string: videoURL) else { return }
        let request = URLRequest(url: url)
        uiView.load(request)
    }
}

struct AprendeView_Previews: PreviewProvider {
    static var previews: some View {
        AprendeView()
    }
}
