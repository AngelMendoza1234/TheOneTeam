import SwiftUI
import Charts

struct InsulinaView: View {
    enum Periodo: String, CaseIterable {
        case semana = "Semana"
        case mes = "Mes"
        case año = "Año"
    }
    
    @State private var periodoSeleccionado: Periodo = .semana
    
    var datos: [GlucosaData] {
        switch periodoSeleccionado {
        case .semana:
            return GlucosaData.datosSemana
        case .mes:
            return GlucosaData.datosMes
        case .año:
            return GlucosaData.datosAño
        }
    }
    
    var body: some View {
        NavigationView {
            VStack {
                
                Picker("Periodo", selection: $periodoSeleccionado) {
                    ForEach(Periodo.allCases, id: \.self) {
                        Text($0.rawValue)
                    }
                }
                .pickerStyle(.segmented)
                .padding()

                Chart(datos) { item in
                    LineMark(
                        x: .value("Fecha", item.fecha, unit: .day),
                        y: .value("Glucosa", item.nivelGlucosa)
                    )
                    .interpolationMethod(.catmullRom)
                    .symbol(Circle())
                    .foregroundStyle(by: .value("Rango", item.nivelGlucosa < 140 ? "Normal" : "Alto"))
                }
                .chartYAxisLabel("mg/dL")
                .frame(height: 300)
                .padding()
                
                Spacer()
            }
            .padding()
            .navigationTitle("Historial de Insulina")
        }
    }
}

#Preview {
    InsulinaView()
}

struct GlucosaData: Identifiable {
    var id = UUID()
    var fecha: Date
    var nivelGlucosa: Double

    static let datosSemana: [GlucosaData] = (0..<7).map { i in
        let base = 160 - (Double(i) * 3)         // Mejora diaria
        let variacion = Double.random(in: -10...10)
        return GlucosaData(
            fecha: Calendar.current.date(byAdding: .day, value: -i, to: Date())!,
            nivelGlucosa: base + variacion
        )
    }.sorted { $0.fecha < $1.fecha }

    static let datosMes: [GlucosaData] = (0..<30).map { i in
        let base = 170 - (Double(i) * 1.5)       // Mejora lenta pero constante
        let variacion = Double.random(in: -15...15)
        return GlucosaData(
            fecha: Calendar.current.date(byAdding: .day, value: -i, to: Date())!,
            nivelGlucosa: max(base + variacion, 80)
        )
    }.sorted { $0.fecha < $1.fecha }

    static let datosAño: [GlucosaData] = (0..<12).map { i in
        let base = 180 - (Double(i) * 6)         // Gran mejora mes a mes
        let variacion = Double.random(in: -10...10)
        return GlucosaData(
            fecha: Calendar.current.date(byAdding: .month, value: -i, to: Date())!,
            nivelGlucosa: max(base + variacion, 80)
        )
    }.sorted { $0.fecha < $1.fecha }
}
