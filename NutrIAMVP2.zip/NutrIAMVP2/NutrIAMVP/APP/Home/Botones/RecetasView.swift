//
//  RecetasView.swift
//  NutrIAMVP
//
//  Created by Samuel Alarcón on 08/06/25.
//


import SwiftUI

struct RecetasView: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    ForEach(recipeData) { receta in
                        NavigationLink(destination: RecipeDetailView(receta: receta)) {
                            RecipeCardView(receta: receta)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                .padding()
            }
            .background(Color(.systemGroupedBackground))
        }
    }
}

struct RecipeCardView: View {
    let receta: Receta

    var body: some View {
        HStack(alignment: .center, spacing: 16) {
            // Texto e ingredientes
            VStack(alignment: .leading, spacing: 8) {
                Text("Control Glucémico")
                    .font(.title2).bold()
                    .foregroundColor(.white)

                VStack(alignment: .leading, spacing: 4) {
                    Text(receta.titulo)
                        .font(.headline)
                        .foregroundColor(.white)

                    Text("INGREDIENTES DE LA RECETA")
                        .font(.caption).bold()
                        .foregroundColor(.white)

                    if let primero = receta.ingredientes.first {
                        Text("• \(primero)")
                            .font(.subheadline)
                            .foregroundColor(.white)
                    }
                }
                .padding()
                .background(cajaInteriorColor(for: receta.icono))
                .cornerRadius(16)
            }

            // Imagen con ícono flotante
            ZStack(alignment: .topTrailing) {
                Image(receta.imagenNombre)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 100, height: 110)
                    .clipShape(RoundedRectangle(cornerRadius: 20))

                Circle()
                    .fill(circuloIconoColor(for: receta.icono))
                    .frame(width: 36, height: 36)
                    .overlay(
                        Image(systemName: receta.icono)
                            .foregroundColor(.white)
                            .font(.system(size: 18, weight: .bold))
                    )
                    .offset(x: -8, y: 8)
            }
        }
        .padding()
        .background(fondoColor(for: receta.icono))
        .cornerRadius(28)
        .shadow(radius: 6)
    }

    // MARK: - Colores según ícono
    func fondoColor(for icono: String) -> LinearGradient {
        switch icono {
        case "sun.horizon":
            return LinearGradient(colors: [.orange, .red.opacity(0.6)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case "sun.max.fill":
            return LinearGradient(colors: [.teal, .cyan.opacity(0.7)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case "moon.fill":
            return LinearGradient(colors: [.black, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
        default:
            return LinearGradient(colors: [.black, .blue], startPoint: .topLeading, endPoint: .bottomTrailing)
        }
    }

    func cajaInteriorColor(for icono: String) -> Color {
        switch icono {
        case "sun.horizon":
            return Color.orange.opacity(0.8)
        case "sun.max.fill":
            return Color.cyan.opacity(0.8)
        case "moon.fill":
            return Color.blue.opacity(0.85)
        default:
            return Color.blue.opacity(0.85)
        }
    }

    func circuloIconoColor(for icono: String) -> Color {
        switch icono {
        case "sun.horizon":
            return Color.orange
        case "sun.max.fill":
            return Color.teal
        case "moon.fill":
            return Color.blue
        default:
            return Color.blue
        }
    }
}

struct RecipeDetailView: View {
    let receta: Receta

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Image(receta.imagenNombre)
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(20)

                Text(receta.titulo)
                    .font(.title)
                    .bold()

                Text("Ingredientes")
                    .font(.headline)
                ForEach(receta.ingredientes, id: \.self) { ingrediente in
                    Text("• \(ingrediente)")
                }

                Divider()

                Text("Preparación")
                    .font(.headline)

                if receta.titulo == "Tostadas integrales con aguacate y tomate" {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. Tuesta la rebanada de pan integral en una tostadora o sartén.")
                        Text("2. Aplasta el aguacate con un tenedor y unta sobre la tostada.")
                        Text("3. Corta el tomate en rodajas finas y colócalo sobre el aguacate.")
                        Text("4. Añade un chorrito de aceite de oliva sobre el tomate.")
                        Text("5. Sazona con un poco de sal y pimienta al gusto.")
                    }
                } 
                else if receta.titulo == "Ensalada de atún con garbanzos" {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. Abre la lata de atún y escúrrelo bien.")
                        Text("2. En un bowl grande, mezcla el atún, los garbanzos cocidos, el pepino cortado en cubos, la cebolla morada picada y el tomate en trozos.")
                        Text("3. Exprime el jugo de un limón sobre la mezcla.")
                        Text("4. Añade un chorrito de aceite de oliva y mezcla bien.")
                        Text("5. Sirve y disfruta.")
                    }
                }
                else if receta.titulo == "Pechuga de pollo al horno con espárragos" {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. Precalienta el horno a 180°C.")
                        Text("2. Sazona la pechuga de pollo con aceite de oliva, el jugo de medio limón, sal y pimienta.")
                        Text("3. Coloca la pechuga de pollo en una bandeja para hornear y hornéala por 25-30 minutos o hasta que esté completamente cocida.")
                        Text("4. Mientras el pollo se hornea, cocina los espárragos al vapor o a la parrilla hasta que estén tiernos.")
                        Text("5. Sirve el pollo junto con los espárragos y disfruta de una cena saludable.")
                    }
                }
                else if receta.titulo == "Avena con frutos rojos y almendras" {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. Cocina la avena en una olla con la leche de almendras hasta que esté suave y cremosa.")
                        Text("2. Agrega los frutos rojos y las almendras picadas cuando la avena ya esté lista.")
                        Text("3. Si lo prefieres, endulza con un poco de miel o stevia al gusto.")
                        Text("4. Sirve y disfruta de un desayuno lleno de energía.")
                    }
                }
                else if receta.titulo == "Sopa de lentejas y espinacas" {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. Sofríe la cebolla y el ajo picados en una sartén con aceite de oliva hasta que estén dorados.")
                        Text("2. Añade las lentejas cocidas y las espinacas frescas.")
                        Text("3. Cocina a fuego lento hasta que las espinacas estén suaves y todo esté bien mezclado.")
                        Text("4. Sirve caliente, ¡y disfruta de una sopa rica en fibra!")
                    }
                }
                else if receta.titulo == "Tacos de portobello con pico de gallo" {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. Asa los hongos portobello en una sartén con un poco de aceite de oliva hasta que estén dorados y tiernos.")
                        Text("2. Corta los hongos en tiras finas para usarlas como relleno.")
                        Text("3. Prepara un pico de gallo picando el tomate, la cebolla morada y el pepino. Añade jugo de limón al gusto.")
                        Text("4. Sirve las tiras de hongo portobello en las tortillas de maíz, cubriendo con el pico de gallo.")
                        Text("5. ¡Listo para disfrutar de unos deliciosos tacos vegetarianos!")
                    }
                }
                else if receta.titulo == "Huevos revueltos con espinacas" {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. Bate los huevos en un bol.")
                        Text("2. Calienta el aceite en una sartén y agrega las espinacas. Cocina hasta que se ablanden.")
                        Text("3. Vierte los huevos batidos en la sartén con las espinacas y revuelve hasta que los huevos estén cocidos.")
                        Text("4. Sazona con sal y pimienta al gusto. ¡Listo para disfrutar!")
                    }
                }
                else if receta.titulo == "Ensalada de pollo con aguacate" {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. Cocina la pechuga de pollo a la plancha y córtala en tiras.")
                        Text("2. En un bol, mezcla la lechuga, los tomates cherry cortados a la mitad, el pepino en rodajas y el aguacate en trozos.")
                        Text("3. Agrega las tiras de pollo a la ensalada y adereza con limón y aceite de oliva al gusto.")
                        Text("4. Sirve y disfruta de una comida fresca y llena de proteínas.")
                    }
                }
                else if receta.titulo == "Salmón a la parrilla con brócoli al vapor" {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("1. Cocina el salmón a la parrilla con un poco de aceite de oliva y jugo de limón hasta que esté dorado por ambos lados.")
                        Text("2. Cocina el brócoli al vapor hasta que esté tierno.")
                        Text("3. Sirve el salmón acompañado del brócoli al vapor.")
                        Text("4. ¡Disfruta de una cena saludable y sabrosa!")
                    }
                }

                else {
                    Text("🔜 Aquí irán los pasos detallados de la receta \(receta.titulo). Puedes personalizar esto receta por receta.")
                        .padding(.top, 8)
                }
            }
            .padding()
        }
        .navigationTitle("Preparación")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct Receta: Identifiable {
    let id = UUID()
    let titulo: String
    let ingredientes: [String]
    let icono: String
    let imagenNombre: String
}

let recipeData = [
    Receta(
        titulo: "Tostadas integrales con aguacate y tomate",
        ingredientes: [
            "1 rebanada de pan integral",
            "1/2 aguacate",
            "1 tomate",
            "Un chorrito de aceite de oliva",
            "Sal y pimienta"
        ],
        icono: "sun.horizon",
        imagenNombre: "tostada"
    ),
    Receta(
        titulo: "Ensalada de atún con garbanzos",
        ingredientes: [
            "1 lata de atún en agua",
            "1/2 taza de garbanzos cocidos",
            "1 pepino",
            "1/2 cebolla morada",
            "1 tomate",
            "Jugo de limón",
            "Aceite de oliva"
        ],
        icono: "sun.max.fill",
        imagenNombre: "atun"
    ),
    Receta(
        titulo: "Pechuga de pollo al horno con espárragos",
        ingredientes: [
            "1 pechuga de pollo",
            "1 cucharadita de aceite de oliva",
            "1/2 limón",
            "1 taza de espárragos",
            "Sal y pimienta"
        ],
        icono: "moon.fill",
        imagenNombre: "pollo"
    ),
    Receta(
        titulo: "Avena con frutos rojos y almendras",
        ingredientes: [
            "1/2 taza de avena",
            "1 taza de leche de almendras sin azúcar",
            "1/4 taza de frutos rojos (fresas, moras)",
            "2 cucharadas de almendras picadas"
        ],
        icono: "sun.horizon",
        imagenNombre: "avena"
    ),
    Receta(
        titulo: "Sopa de lentejas y espinacas",
        ingredientes: [
            "1 taza de lentejas cocidas",
            "1 taza de espinacas frescas",
            "1/2 cebolla",
            "1 diente de ajo",
            "1 cucharadita de aceite de oliva"
        ],
        icono: "sun.max.fill",
        imagenNombre: "sopa"
    ),
    Receta(
        titulo: "Tacos de portobello con pico de gallo",
        ingredientes: [
            "2 hongos portobello",
            "1/4 de cebolla morada",
            "1 tomate",
            "1/4 de pepino",
            "1 cucharadita de aceite de oliva",
            "Tortillas de maíz"
        ],
        icono: "moon.fill",
        imagenNombre: "tacos"
    ),
    Receta(
        titulo: "Huevos revueltos con espinacas",
        ingredientes: [
            "2 huevos",
            "1 taza de espinacas",
            "1 cucharadita de aceite de oliva",
            "Sal y pimienta"
        ],
        icono: "sun.horizon",
        imagenNombre: "huevos"
    ),
    Receta(
        titulo: "Ensalada de pollo con aguacate",
        ingredientes: [
            "1 pechuga de pollo a la plancha",
            "1 aguacate",
            "Lechuga",
            "Tomates cherry",
            "Pepino"
        ],
        icono: "sun.max.fill",
        imagenNombre: "ensalada"
    ),
    Receta(
        titulo: "Salmón a la parrilla con brócoli al vapor",
        ingredientes: [
            "1 filete de salmón",
            "1 taza de brócoli",
            "1 cucharadita de aceite de oliva",
            "Jugo de limón"
        ],
        icono: "moon.fill",
        imagenNombre: "salmon"
    )
]

#Preview {
    RecetasView()
}