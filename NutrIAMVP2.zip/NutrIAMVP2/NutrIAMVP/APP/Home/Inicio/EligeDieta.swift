import SwiftUI

struct EligeDieta: View {
    // Este binding viene de ContentView
    @Binding var hasUserInfo: Bool
    @State private var selectedIndex: Int = 0

    var body: some View {
        VStack(spacing: 16) {
            Text("¡ELIGE TU DIETA!")
                .font(.system(size: 36, weight: .bold))
                .multilineTextAlignment(.center)
                .padding(.top, 24)

            GeometryReader { proxy in
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 4) {
                        ForEach(Array(MockData.items.enumerated()), id: \.1.id) { index, item in
                            GeometryReader { geo in
                                let midX = geo.frame(in: .global).midX
                                let screenMidX = proxy.frame(in: .global).midX
                                let distance = abs(screenMidX - midX)
                                let scale = max(0.8, 1 - (distance / proxy.size.width))

                                ZStack {
                                    RoundedRectangle(cornerRadius: 25)
                                        .fill(item.color.gradient)
                                        .frame(height: 300)

                                    VStack(spacing: 12) {
                                        Image(item.imageAsset)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: 80)
                                        Text(item.title)
                                            .font(.headline)
                                            .foregroundColor(.black)
                                    }
                                    .padding()
                                }
                                .scaleEffect(scale)
                                .opacity(scale)
                                .onChange(of: scale) { _ in
                                    if scale > 0.95 {
                                        selectedIndex = index
                                    }
                                }
                            }
                            .frame(width: proxy.size.width * 0.6, height: 300)
                        }
                    }
                    .padding(.horizontal, proxy.size.width * 0.15)
                }
            }
            .frame(height: 320)

            VStack {
                Divider().padding(.vertical, 8)
                Text(MockData.items[selectedIndex].description)
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .padding()
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(20)
                    .padding()
            }

            // Botón para entrar al flujo de EmpecemosView
            NavigationLink {
                EmpecemosView(hasUserInfo: $hasUserInfo)
            } label: {
                Text("Continuar con “\(MockData.items[selectedIndex].title)”")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(12)
            }
            .padding(.horizontal)

            Spacer()
        }
        .padding(.bottom, 30)
        .navigationTitle("Elige Dieta")
    }
}

#Preview {
    // Preview con binding constante
    EligeDieta(hasUserInfo: .constant(false))
}

struct Item: Identifiable {
    let id = UUID()
    let color: Color
    let title: String
    let imageAsset: String
    let description: String
}

struct MockData {
    static let items = [
        Item(
            color: .teal,
            title: "Control Glucémico",
            imageAsset: "control_glucemico",
            description: "Dieta para controlar el índice glucémico..."
        ),
        Item(
            color: .orange,
            title: "Déficit Calórico",
            imageAsset: "deficit_calorico",
            description: "Dieta para perder peso reduciendo calorías..."
        ),
        Item(
            color: .purple,
            title: "Dieta MIND",
            imageAsset: "dieta_mind",
            description: "Dieta enfocada en la salud cerebral..."
        )
    ]
}
