import SwiftUI

struct EmpecemosView: View {
    @Binding var hasUserInfo: Bool

    // Persistencia
    @AppStorage("nombre")     private var nombreStorage = ""
    @AppStorage("edad")       private var edadStorage = ""
    @AppStorage("peso")       private var pesoStorage = ""
    @AppStorage("estatura")   private var estaturaStorage = ""
    @AppStorage("sexo")       private var sexoStorage = "Masculino"
    @AppStorage("actividad")  private var actividadStorage = ""
    @AppStorage("enfermedad") private var enfermedadStorage = ""

    // Estados
    @State private var nombre = ""
    @State private var edad = ""
    @State private var peso = ""
    @State private var estatura = ""
    @State private var sexo = "Masculino"
    @State private var actividadNivelIndex = 1
    @State private var enfermedadGlucosa = ""

    // Overlays
    @State private var mostrarEdad = false
    @State private var mostrarPeso = false
    @State private var mostrarOpcionesActividad = false
    @State private var mostrarEnfermedades = false

    // Confirmación
    @State private var showConfirmation = false

    // Datos
    let edades = Array(10...100).map { "\($0)" }
    let pesos  = Array(30...150).map { "\($0) kg" }
    let actividades = ["Null","Sedentaria","Ligeramente activa","Moderadamente activa","Activa","Muy activa"]
    let enfermedadesGlucosa = ["Ninguna","Diabetes tipo 1","Diabetes tipo 2","Hipoglucemia","Prediabetes"]

    // Computados
    private var actividadSeleccionada: String {
        guard actividadNivelIndex > 0, actividadNivelIndex < actividades.count else { return "Desconocida" }
        return actividades[actividadNivelIndex]
    }
    private var colorActividad: Color {
        switch actividadNivelIndex {
        case 1: return .red
        case 2: return Color(red: 1, green: 0.6, blue: 0)
        case 3: return .yellow
        case 4: return Color(red: 0.8, green: 0.9, blue: 0)
        case 5: return .green
        default: return .gray
        }
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                campoTexto(titulo: "Nombre", texto: $nombre)

                HStack(spacing: 23) {
                    campoBoton(label: "Edad", value: edad, placeholder: "Selecciona tu edad") {
                        mostrarEdad = true
                    }
                    campoBoton(label: "Peso", value: peso, placeholder: "Selecciona tu peso") {
                        mostrarPeso = true
                    }
                }

                campoTexto(titulo: "Estatura", texto: $estatura)

                Text("Sexo")
                    .font(.system(size: 20))
                Picker("", selection: $sexo) {
                    Text("Masculino").tag("Masculino")
                    Text("Femenino").tag("Femenino")
                }
                .pickerStyle(.segmented)

                Text("Actividad física")
                    .font(.system(size: 20))
                Slider(
                    value: Binding(
                        get: { Double(actividadNivelIndex) },
                        set: { actividadNivelIndex = max(1, Int($0.rounded())) }
                    ),
                    in: 0...5, step: 1
                )
                .accentColor(colorActividad)

                Button(actividadSeleccionada) {
                    mostrarOpcionesActividad = true
                }
                .botonEstilo()

                Text("¿Enfermedad de glucosa?")
                    .font(.system(size: 20))
                Button(enfermedadGlucosa.isEmpty ? "Selecciona una opción" : enfermedadGlucosa) {
                    mostrarEnfermedades = true
                }
                .botonEstilo()

                Button("Continuar") {
                    // Guardar
                    nombreStorage      = nombre
                    edadStorage        = edad
                    pesoStorage        = peso
                    estaturaStorage    = estatura
                    sexoStorage        = sexo
                    actividadStorage   = actividadSeleccionada
                    enfermedadStorage  = enfermedadGlucosa
                    // Mostrar alerta y luego navegar
                    showConfirmation = true
                }
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.blue)
                .cornerRadius(15)

                Spacer(minLength: 40)
            }
            .padding(.horizontal, 30)
            .padding(.vertical, 10)
        }
        .navigationTitle("¡EMPECEMOS!")
        .overlay(overlays)
        .alert("Datos guardados", isPresented: $showConfirmation) {
            Button("OK") { hasUserInfo = true }
        } message: {
            Text("Cualquiera de esta información la puedes cambiar en la configuración de la app.")
        }
    }

    // MARK: - Overlay Builder
    @ViewBuilder
    private var overlays: some View {
        if mostrarEdad {
            opcionOverlay(
                title: "Selecciona tu edad",
                opciones: edades,
                onSelect: {
                    edad = $0
                    mostrarEdad = false
                },
                onCancel: {
                    mostrarEdad = false
                }
            )
        }
        if mostrarPeso {
            opcionOverlay(
                title: "Selecciona tu peso",
                opciones: pesos,
                onSelect: {
                    peso = $0
                    mostrarPeso = false
                },
                onCancel: {
                    mostrarPeso = false
                }
            )
        }
        if mostrarOpcionesActividad {
            opcionOverlay(
                title: "Selecciona tu actividad física",
                opciones: Array(actividades.dropFirst()),
                onSelect: {
                    // +1 porque `dropFirst()` quita el index 0
                    actividadNivelIndex = actividades.firstIndex(of: $0) ?? 1
                    mostrarOpcionesActividad = false
                },
                onCancel: {
                    mostrarOpcionesActividad = false
                }
            )
        }
        if mostrarEnfermedades {
            opcionOverlay(
                title: "Selecciona una condición",
                opciones: enfermedadesGlucosa,
                onSelect: {
                    enfermedadGlucosa = $0
                    mostrarEnfermedades = false
                },
                onCancel: {
                    mostrarEnfermedades = false
                }
            )
        }
    }

    // MARK: - Componente Overlay
    private func opcionOverlay(
        title: String,
        opciones: [String],
        onSelect: @escaping (String) -> Void,
        onCancel: @escaping () -> Void
    ) -> some View {
        ZStack {
            Color.black.opacity(0.4)
                .ignoresSafeArea()
                .onTapGesture(perform: onCancel)

            VStack(spacing: 20) {
                Text(title).font(.headline)

                ScrollView {
                    VStack(spacing: 10) {
                        ForEach(opciones, id: \.self) { opt in
                            Button(opt) {
                                onSelect(opt)
                            }
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color(white: 0.9))
                            .cornerRadius(10)
                        }
                    }
                }

                Button("Cancelar", action: onCancel)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.red)
                    .padding(.bottom, 10)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(25)
            .shadow(radius: 10)
            .padding(.horizontal, 50)
        }
        .transition(.move(edge: .bottom))
    }

    // MARK: - Helpers
    private func campoTexto(titulo: String, texto: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(titulo).font(.system(size: 20))
            TextField("", text: texto)
                .padding(10)
                .background(Color(white: 0.95))
                .cornerRadius(10)
                .frame(height: 40)
        }
    }

    private func campoBoton(
        label: String,
        value: String,
        placeholder: String,
        action: @escaping () -> Void
    ) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label).font(.system(size: 20))
            Button(action: action) {
                Text(value.isEmpty ? placeholder : value)
                    .foregroundColor(value.isEmpty ? .gray : .black)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color(white: 0.95))
                    .cornerRadius(10)
            }
        }
    }
}

// Botón estilo reusable
private extension View {
    func botonEstilo() -> some View {
        self.font(.system(size: 18))
            .padding(10)
            .frame(maxWidth: .infinity)
            .background(Color.black)
            .foregroundColor(.white)
            .cornerRadius(20)
    }
}

#Preview {
    EmpecemosView(hasUserInfo: .constant(false))
}
