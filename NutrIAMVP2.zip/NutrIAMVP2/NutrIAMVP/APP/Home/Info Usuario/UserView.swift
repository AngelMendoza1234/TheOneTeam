import SwiftUI

struct UserView: View {
    let user: Usuario

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            campoLectura(titulo: "Nombre", valor: user.nombre)
            HStack(spacing: 20) {
                campoLectura(titulo: "Edad", valor: user.edad)
                campoLectura(titulo: "Peso", valor: user.peso)
            }
            HStack(spacing: 20) {
                campoLectura(titulo: "Estatura", valor: user.estatura)
                campoLectura(titulo: "Sexo", valor: user.sexo)
            }
            HStack(spacing: 20) {
                campoLectura(titulo: "Actividad Física", valor: user.actividadFisica)
                campoLectura(titulo: "Enfermedades", valor: user.enfermedades)
            }
            Spacer()
        }
        .padding()
        .navigationTitle("Tus Datos")
    }

    private func campoLectura(titulo: String, valor: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(titulo).font(.headline)
            RoundedRectangle(cornerRadius: 8)
                .fill(Color(.systemGray5))
                .frame(height: 40)
                .overlay(
                    Text(valor).foregroundColor(.black).padding(.horizontal),
                    alignment: .leading
                )
        }
    }
}

struct UserView_Previews: PreviewProvider {
    static var previews: some View {
        UserView(user: Usuario(
            nombre: "Ana",
            edad: "25",
            peso: "65 kg",
            estatura: "1.68 m",
            sexo: "Femenino",
            actividadFisica: "Moderadamente activa",
            enfermedades: "Ninguna"
        ))
    }
}
