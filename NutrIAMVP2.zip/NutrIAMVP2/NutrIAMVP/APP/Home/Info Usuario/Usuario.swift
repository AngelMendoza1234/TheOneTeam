//
//  Usuario.swift
//  NutrIA
//
//  Created by Samuel Alarcón on 07/06/25.
//


import Foundation

struct Usuario: Identifiable {
    let id = UUID()
    let nombre: String
    let edad: String
    let peso: String
    let estatura: String
    let sexo: String
    let actividadFisica: String
    let enfermedades: String
}
