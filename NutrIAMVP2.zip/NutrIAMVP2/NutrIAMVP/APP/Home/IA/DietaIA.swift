import SwiftUI
import PhotosUI

struct DietaIA: View {
    // MARK: – Estado de la IA
    @State private var antojo: String = ""
    @State private var refriItems: [String] = [""]

    // MARK: – PhotosPicker
    @State private var selectedItem: PhotosPickerItem? = nil
    @State private var selectedImage: UIImage? = nil

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("¿Qué se te antoja?")) {
                    TextField("Ej: ensalada, pollo, pasta…", text: $antojo)
                        .textFieldStyle(.roundedBorder)
                }

                Section(header: Text("Qué hay en tu refri")) {
                    ForEach(refriItems.indices, id: \.self) { idx in
                        HStack {
                            TextField("Ingrediente", text: $refriItems[idx])
                            if refriItems.count > 1 {
                                Button(action: {
                                    refriItems.remove(at: idx)
                                }) {
                                    Image(systemName: "minus.circle.fill")
                                        .foregroundColor(.red)
                                }
                            }
                        }
                    }
                    Button(action: {
                        refriItems.append("")
                    }) {
                        Label("Agregar ingrediente", systemImage: "plus.circle")
                    }
                }

                Section {
                    PhotosPicker(
                        selection: $selectedItem,
                        matching: .images,
                        photoLibrary: .shared()
                    ) {
                        Label("Tomar o seleccionar foto de tu refri", systemImage: "camera")
                    }
                    .onChange(of: selectedItem) { newItem in
                        Task {
                            if let data = try? await newItem?.loadTransferable(type: Data.self),
                               let uiImage = UIImage(data: data) {
                                selectedImage = uiImage
                            }
                        }
                    }
                    if let image = selectedImage {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 150)
                            .cornerRadius(8)
                    }
                }

                Section {
                    Button(action: generarReceta) {
                        Text("Generar receta con IA")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                    }
                }
            }
            .navigationTitle("Dieta con IA")
        }
    }

    // MARK: – Simulación de llamada a tu IA
    func generarReceta() {
        let ingredientes = refriItems.filter { !$0.isEmpty }
        print("Antojo:", antojo)
        print("Refri:", ingredientes)
        if let _ = selectedImage {
            print("Imagen disponible para análisis")
        }
        // Aquí llama a tu servicio de IA pasando: antojo, ingredientes, selectedImage
    }
}

#Preview {
    DietaIA()
}
