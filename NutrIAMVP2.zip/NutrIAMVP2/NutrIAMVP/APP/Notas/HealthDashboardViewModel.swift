import Foundation

class HealthDashboardViewModel: ObservableObject {
    @Published var healthStats: HealthStats
    @Published var dailySummaries: [DailyHealthSummary] = []

    init() {
        // Inicialización vacía o con notas precargadas
        self.dailySummaries = []
        self.healthStats = HealthStats(
            currentGlucose: 0,
            averageGlucose7Days: 0,
            glucoseVariabilityPercentage: 0,
            timeInRangePercentage: 0,
            hba1cPercentage: 0,
            currentWeightKg: 0,
            bloodPressureSystolic: 0,
            bloodPressureDiastolic: 0
        )
    }

    /// Añade una nueva nota y recalcula todas las estadísticas a partir de dailySummaries
    func addDailySummary(
        averageGlucose: Double,
        timeInRange: Double,
        variability: Double,
        hba1c: Double,
        bpSystolic: Int,
        bpDiastolic: Int,
        note: String
    ) {
        let new = DailyHealthSummary(
            date: Date(),
            averageGlucose: averageGlucose,
            timeInRangePercentage: timeInRange,
            glucoseVariabilityPercentage: variability,
            glucoseDayValues: [],
            hba1cPercentage: hba1c,
            bloodPressureSystolic: bpSystolic,
            bloodPressureDiastolic: bpDiastolic,
            userNote: note
        )
        dailySummaries.insert(new, at: 0)
        recalcStats()
    }

    /// Recalcula **todos** los valores de healthStats:
    /// - Última nota → currentGlucose, variability, TIR, HbA1c, presión
    /// - Todas las notas → promedio de glucosa
    private func recalcStats() {
        guard !dailySummaries.isEmpty else { return }

        let latest = dailySummaries[0]

        // 1) Datos de la última nota
        healthStats.currentGlucose               = latest.averageGlucose
        healthStats.glucoseVariabilityPercentage = latest.glucoseVariabilityPercentage
        healthStats.timeInRangePercentage        = latest.timeInRangePercentage
        healthStats.hba1cPercentage              = latest.hba1cPercentage
        healthStats.bloodPressureSystolic        = latest.bloodPressureSystolic
        healthStats.bloodPressureDiastolic       = latest.bloodPressureDiastolic

        // 2) Promedio de glucosa de **todas** las notas
        let totalGlucose = dailySummaries
            .map(\.averageGlucose)
            .reduce(0, +)
        healthStats.averageGlucose7Days = totalGlucose / Double(dailySummaries.count)
    }
}
