import SwiftUI

struct DailySummaryCard: View {
    @Environment(\.colorScheme) var colorScheme
    var summary: DailyHealthSummary

    // MARK: — Cálculos de fechas
    private var isToday: Bool {
        Calendar.current.isDateInToday(summary.date)
    }
    private var isYesterday: Bool {
        Calendar.current.isDateInYesterday(summary.date)
    }
    
    // Etiqueta dinámica arriba
    private var headerText: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "d MMM"         // e.g. "7 Jun"
        let dateStr = formatter.string(from: summary.date)
        
        if isToday {
            return "Hoy, \(dateStr)"
        } else if isYesterday {
            return "Ayer, \(dateStr)"
        } else {
            formatter.dateFormat = "d MMM yyyy" // e.g. "3 Jun 2025"
            return formatter.string(from: summary.date)
        }
    }

    var body: some View {
        HStack(alignment: .top) {
            // Texto principal
            VStack(alignment: .leading, spacing: 6) {
                Text(headerText)
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundColor(.primary)
                
                // Detalle solo para Hoy
                if isToday {
                    Text("Glucosa prom.: \(Int(summary.averageGlucose)) mg/dL")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text("TIR: \(Int(summary.timeInRangePercentage)) %")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text("Variabilidad: \(Int(summary.glucoseVariabilityPercentage)) %")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                // Nota siempre
                HStack(alignment: .top, spacing: 4) {
                    Text("Nota:")
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    Text(summary.userNote)
                        .foregroundColor(.primary)
                }
                .padding(.top, 4)
            }
            
            Spacer()
            
            // Donut chart de TIR
            DonutChartView(
                data: [
                    summary.timeInRangePercentage,
                    max(0, 100 - summary.timeInRangePercentage)
                ],
                colors: [Color.blue, Color.green]
            )
            .frame(width: 60, height: 60)
        }
        .padding()
        .background(Color(.systemBackground))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color(.separator), lineWidth: 1)
        )
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(colorScheme == .light ? 0.05 : 0),
                radius: 3, x: 0, y: 1)
        .padding(.horizontal)
    }
}

struct DailySummaryCard_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 16) {
            // Hoy
            DailySummaryCard(summary: DailyHealthSummary(
                date: Date(),
                averageGlucose: 126,
                timeInRangePercentage: 75,
                glucoseVariabilityPercentage: 30,
                glucoseDayValues: [],
                hba1cPercentage: 6.8,
                bloodPressureSystolic: 120,
                bloodPressureDiastolic: 78,
                userNote: "Hipoglucemia en la tarde."
            ))
            // Ayer
            DailySummaryCard(summary: DailyHealthSummary(
                date: Calendar.current.date(byAdding: .day, value: -1, to: Date())!,
                averageGlucose: 130,
                timeInRangePercentage: 68,
                glucoseVariabilityPercentage: 35,
                glucoseDayValues: [],
                hba1cPercentage: 7.2,
                bloodPressureSystolic: 125,
                bloodPressureDiastolic: 80,
                userNote: "Día estable."
            ))
        }
        .background(Color(.systemBackground))
    }
}
