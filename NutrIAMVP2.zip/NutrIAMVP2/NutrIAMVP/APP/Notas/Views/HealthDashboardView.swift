import SwiftUI

struct HealthDashboardView: View {
    @StateObject private var viewModel = HealthDashboardViewModel()
    @State private var showingAddNote = false
    
    // Altura y diámetro fijos
    private let cardHeight: CGFloat = 180
    private let circleDiameter: CGFloat = 80
    
    // Tipo alias para datos de estadística
    private typealias Stat = (title: String, value: String, unit: String, color: Color)
    
    // Periodos
        private let periods = ["Semana", "Mes", "Año"]
        @State private var selectedPeriod = 0

    // Datos ordenados en un array
    private var statsData: [Stat] {
        [
            ("Glucosa", "\(Int(viewModel.healthStats.currentGlucose))", "mg/dL", .orange),
            ("Glucosa Promedio", "\(Int(viewModel.healthStats.averageGlucose7Days))", "mg/dL", Color.green.opacity(0.6)),
            ("Variabilidad", "\(Int(viewModel.healthStats.glucoseVariabilityPercentage))", "%", .blue),
            ("HbA1c", "\(viewModel.healthStats.hba1cPercentage)", "%", Color.orange.opacity(0.8)),
            ("Presión arterial",
             "\(viewModel.healthStats.bloodPressureSystolic)/\(viewModel.healthStats.bloodPressureDiastolic)",
             "mmHg", .purple),
            ("TIR", "\(Int(viewModel.healthStats.timeInRangePercentage))", "%", Color.purple.opacity(0.8))
        ]
    }

    // Dividir en dos filas de tres
    private var firstRow: [Stat] { Array(statsData.prefix(3)) }
    private var secondRow: [Stat] { Array(statsData.dropFirst(3).prefix(3)) }

    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemGray6)
                    .ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 16) {
                        // Ya no necesitamos HStack de encabezado aquí
                        // porque lo movemos al navigation bar.

                        // Sección "Tu estado"
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Tu ultimo estado:")
                                .font(.headline)
                                .padding(.horizontal)

                            VStack(spacing: 12) {
                                HStack(spacing: 12) {
                                    ForEach(firstRow, id: \.title) { stat in
                                        statCard(for: stat)
                                    }
                                }
                                HStack(spacing: 12) {
                                    ForEach(secondRow, id: \.title) { stat in
                                        statCard(for: stat)
                                    }
                                }
                            }
                            .padding(.horizontal)
                        }
                        .padding(.top)
                        

                        // Sección "Tu semana"
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Tu semana:")
                                .font(.title2)
                                .fontWeight(.semibold)
                                .padding(.horizontal)

                            ForEach(viewModel.dailySummaries) { summary in
                                DailySummaryCard(summary: summary)
                            }
                        }
                        .padding(.bottom)
                    }
                    .padding(.vertical)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                // Colocamos el título y el botón juntos en la zona 'principal'
                ToolbarItem(placement: .principal) {
                    HStack {
                        Text("Reporte de notas")
                            .font(.title)
                            .fontWeight(.semibold)
                        Spacer()
                        Button {
                            showingAddNote = true
                        } label: {
                            Image(systemName: "plus.circle.fill")
                                .font(.title)
                                .foregroundColor(.red)
                        }
                    }
                }
            }
            .sheet(isPresented: $showingAddNote) {
                AddNoteView(viewModel: viewModel)
            }
        }
    }

    // MARK: - Tarjeta estadística
    @ViewBuilder
    private func statCard(for data: Stat) -> some View {
        RoundedRectangle(cornerRadius: 12)
            .fill(Color.white)
            .frame(height: cardHeight)
            .shadow(color: .gray.opacity(0.2), radius: 4, x: 0, y: 2)
            .overlay(
                VStack(spacing: 12) {
                    Text(data.title)
                        .font(.subheadline)
                        .multilineTextAlignment(.center)

                    ZStack {
                        Circle()
                            .fill(data.color)
                            .frame(width: circleDiameter, height: circleDiameter)
                        Text(data.value)
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                    }

                    Text(data.unit)
                        .font(.footnote)
                        .foregroundColor(.gray)
                }
                .padding(.vertical, 16)
                .padding(.horizontal, 8)
            )
    }
}

struct HealthDashboardView_Previews: PreviewProvider {
    static var previews: some View {
        HealthDashboardView()
    }
}
