import SwiftUI

struct AddNoteView: View {
    @ObservedObject var viewModel: HealthDashboardViewModel
    @Environment(\.presentationMode) var presentationMode

    @State private var avgGlucose = ""
    @State private var tir = ""
    @State private var variability = ""
    @State private var hba1c = ""
    @State private var bpSys = ""
    @State private var bpDia = ""
    @State private var noteText = ""

    // Filtrado de entrada numérica
    private func filtered(_ text: String) -> String {
        let allowed = CharacterSet(charactersIn: "0123456789.")
        return String(text.unicodeScalars.filter { allowed.contains($0) })
    }

    // Bindings que aplican el filtro en set
    private var avgGlucoseBinding: Binding<String> {
        Binding(get: { avgGlucose },
                set: { new in avgGlucose = filtered(new) })
    }
    private var tirBinding: Binding<String> {
        Binding(get: { tir },
                set: { new in tir = filtered(new) })
    }
    private var variabilityBinding: Binding<String> {
        Binding(get: { variability },
                set: { new in variability = filtered(new) })
    }

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Estadísticas del día")) {
                    TextField("Glucosa promedio (mg/dL)", text: avgGlucoseBinding)
                        .keyboardType(.decimalPad)
                    TextField("Time In Range (%)", text: tirBinding)
                        .keyboardType(.decimalPad)
                    TextField("Variabilidad (%)", text: variabilityBinding)
                        .keyboardType(.decimalPad)
                    TextField("HbA1c (%)", text: Binding(
                        get: { hba1c },
                        set: { new in hba1c = filtered(new) }
                    ))
                    .keyboardType(.decimalPad)
                    TextField("Presión Sistólica (mmHg)", text: Binding(
                        get: { bpSys },
                        set: { new in bpSys = filtered(new) }
                    ))
                    .keyboardType(.numberPad)
                    TextField("Presión Diastólica (mmHg)", text: Binding(
                        get: { bpDia },
                        set: { new in bpDia = filtered(new) }
                    ))
                    .keyboardType(.numberPad)
                }

                Section(header: Text("Nota")) {
                    TextEditor(text: $noteText)
                        .frame(height: 100)
                }
            }
            .navigationBarTitle("Nueva nota", displayMode: .inline)
            .navigationBarItems(
                leading: Button("Cancelar") {
                    presentationMode.wrappedValue.dismiss()
                },
                trailing: Button("Guardar") {
                    // Convertir cada campo
                    let avg     = Double(avgGlucose)      ?? 0
                    let tirVal  = Double(tir)             ?? 0
                    let varVal  = Double(variability)     ?? 0
                    let hba     = Double(hba1c)           ?? 0
                    let sys     = Int(bpSys)              ?? 0
                    let dia     = Int(bpDia)              ?? 0

                    // Llamada extendida al ViewModel
                    viewModel.addDailySummary(
                        averageGlucose: avg,
                        timeInRange: tirVal,
                        variability: varVal,
                        hba1c: hba,
                        bpSystolic: sys,
                        bpDiastolic: dia,
                        note: noteText
                    )
                    presentationMode.wrappedValue.dismiss()
                }
            )
        }
    }
}

struct AddNoteView_Previews: PreviewProvider {
    static var previews: some View {
        AddNoteView(viewModel: HealthDashboardViewModel())
    }
}
