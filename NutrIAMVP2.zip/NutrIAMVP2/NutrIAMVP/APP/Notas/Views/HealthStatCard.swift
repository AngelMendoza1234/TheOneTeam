import SwiftUI

struct HealthStatCard: View {
    let title: String
    let value: String
    let unit: String
    let circleColor: Color
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        VStack(spacing: 12) {
            // Título adaptativo
            Text(title)
                .font(.headline)
                .foregroundColor(.primary)        // ← dinámico
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .minimumScaleFactor(0.75)

            ZStack {
                Circle()
                    .fill(circleColor)
                    .frame(width: 68, height: 68)
                Text(value)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.white)       // value siempre blanco
            }

            Text(unit)
                .font(.caption)
                .foregroundColor(.secondary)     // ← dinámico
        }
        .padding()
        .frame(maxWidth: .infinity, minHeight: 160)
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: Color.black.opacity(colorScheme == .light ? 0.05 : 0),
                radius: 3, x: 0, y: 1)
    }
}

