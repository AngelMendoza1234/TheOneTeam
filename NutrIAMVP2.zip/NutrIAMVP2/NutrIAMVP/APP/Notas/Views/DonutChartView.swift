import SwiftUI

/// Gráfico de anillo (donut) que muestra cada segmento proporcional al total.
struct DonutChartView: View {
    let data: [Double]
    let colors: [Color]
    let lineWidth: CGFloat = 16

    /// Ángulos de final de cada segmento (cumulativos)
    private var segments: [Angle] {
        let total = data.reduce(0, +)
        var currentAngle: Double = 0
        return data.map { value in
            let end = Angle.degrees(currentAngle / total * 360)
            currentAngle += value
            return end
        }
    }

    var body: some View {
        GeometryReader { proxy in
            let size = min(proxy.size.width, proxy.size.height)
            let center = CGPoint(x: proxy.size.width/2, y: proxy.size.height/2)
            let radius = (size - lineWidth) / 2

            ZStack {
                ForEach(data.indices, id: \.self) { index in
                    let startAngle: Angle = index == 0
                        ? .degrees(0)
                        : segments[index - 1]
                    let endAngle = segments[index]

                    Path { path in
                        path.addArc(
                            center: center,
                            radius: radius,
                            startAngle: startAngle,
                            endAngle: endAngle,
                            clockwise: false
                        )
                    }
                    .stroke(
                        colors[index],
                        style: StrokeStyle(lineWidth: lineWidth, lineCap: .butt)
                    )
                }
            }
        }
        .aspectRatio(1, contentMode: .fit)
    }
}

struct DonutChartView_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 30) {
            // Paleta vibrante 1: tonos neón / saturados
            DonutChartView(
                data: [75, 25],
                colors: [
                    Color.pink,               // 75% rosa neón
                    Color.purple.opacity(0.5) // 25% púrpura suave
                ]
            )
            .frame(width: 80, height: 80)

            // Paleta vibrante 2: arcoíris suave
            DonutChartView(
                data: [40, 30, 30],
                colors: [
                    Color(red: 0.95, green: 0.47, blue: 0.31), // salmón
                    Color(red: 0.98, green: 0.77, blue: 0.18), // amarillo
                    Color(red: 0.36, green: 0.67, blue: 0.91)  // celeste
                ]
            )
            .frame(width: 80, height: 80)
        }
        .padding()
        .background(Color(.systemGroupedBackground))
        .previewLayout(.sizeThatFits)
    }
}
