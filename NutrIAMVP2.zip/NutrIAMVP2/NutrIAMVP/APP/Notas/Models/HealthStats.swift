struct HealthStats {
    var currentGlucose: Double
    var averageGlucose7Days: Double
    var glucoseVariabilityPercentage: Double
    var timeInRangePercentage: Double
    var hba1cPercentage: Double
    var currentWeightKg: Double
    var bloodPressureSystolic: Int
    var bloodPressureDiastolic: Int
}
