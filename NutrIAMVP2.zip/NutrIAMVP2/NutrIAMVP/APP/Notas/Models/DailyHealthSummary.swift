
import Foundation

struct DailyHealthSummary: Identifiable {
    var id = UUID()
    var date: Date
    var averageGlucose: Double
    var timeInRangePercentage: Double
    var glucoseVariabilityPercentage: Double
    var glucoseDayValues: [Double]
    var hba1cPercentage: Double        // ← nuevo
    var bloodPressureSystolic: Int     // ← nuevo
    var bloodPressureDiastolic: Int    // ← nuevo
    var userNote: String
}

