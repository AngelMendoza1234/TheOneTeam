//
//  SettingsView.swift
//  NutrIA
//
//  Created by Samuel Alarcón on 07/06/25.
//


import SwiftUI

struct SettingsView: View {
    @ObservedObject var settings: SettingsViewModel
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text(settings.appLanguage == .english ? "Appearance" : "Apariencia")) {
                    Picker(settings.appLanguage == .english ? "Theme" : "Tema", selection: $settings.appTheme) {
                        ForEach(AppTheme.allCases, id: \.self) { theme in
                            Text(theme.rawValue)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }
                
                Section(header: Text(settings.appLanguage == .english ? "Language" : "Idioma")) {
                    Picker(settings.appLanguage == .english ? "Language" : "Idioma", selection: $settings.appLanguage) {
                        ForEach(Language.allCases, id: \.self) { language in
                            Text(language.rawValue)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }
            }
            .navigationTitle(settings.appLanguage == .english ? "Settings" : "Ajustes")
        }
    }
}

#Preview {
    SettingsView(settings: SettingsViewModel())
}