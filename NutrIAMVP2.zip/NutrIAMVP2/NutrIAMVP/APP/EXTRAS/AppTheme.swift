//
//  AppTheme.swift
//  NutrIA
//
//  Created by Samuel Alarcón on 07/06/25.
//


enum AppTheme: String, CaseIterable {
    case light = "Light"
    case dark = "Dark"
}

enum Language: String, CaseIterable {
    case english = "English"
    case spanish = "Español"
}