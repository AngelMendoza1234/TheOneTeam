import SwiftUI

struct MainView: View {
    @StateObject var settings = SettingsViewModel()
    
    var body: some View {
        TabView {
            // — Inicio —
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text(settings.appLanguage == .english ? "Home" : "Inicio")
                }
            
            // — Notas —
            HealthDashboardView()
                .tabItem {
                    Image(systemName: "chart.pie.fill")
                    Text(settings.appLanguage == .english ? "Notes" : "Notas")
                }
            
            // — Ajustes —
            SettingsView(settings: settings)
                .tabItem {
                    Image(systemName: "gearshape.fill")
                    Text(settings.appLanguage == .english ? "Settings" : "Ajustes")
                }
        }
        .preferredColorScheme(settings.appTheme == .dark ? .dark : .light)
        .environmentObject(settings)      // ← aquí lo inyectas
    }
}

#Preview {
    MainView()
}
