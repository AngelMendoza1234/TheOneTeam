import SwiftUI
import UserNotifications

struct Alarma: Identifiable, Equatable {
    let id = UUID()
    let hora: Date
    let descripcion: String
}

struct HomeView: View {
    @Environment(\.colorScheme) private var colorScheme
    @State private var mostrarAlarmaSheet = false
    @State private var alarmas: [Alarma] = []

    init() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { granted, error in
            if let error = error {
                print("Error solicitando permiso: \(error)")
            } else {
                print("Permiso concedido: \(granted)")
            }
        }
    }

    var body: some View {
        NavigationView {
            ZStack(alignment: .bottom) {
                // Fondo adaptable
                Color(.systemBackground)
                    .ignoresSafeArea()

                VStack(spacing: 0) {
                    // Fondo superior
                    ZStack {
                        Color("cielo")
                            .frame(height: 160)
                            .ignoresSafeArea(edges: .top)

                        HStack {
                            Image("nutria")
                                .resizable()
                                .frame(width: 60, height: 60)
                                .padding(.top, -40)
                            Spacer()
                            Text("NutrIA")
                                .font(.system(size: 45, weight: .bold))
                                .foregroundColor(Color("aqua"))
                                .padding(.top, -40)
                            Spacer()
                        }
                        .padding(.horizontal)
                    }

                    // Botones principales
                    VStack(spacing: 25) {
                        HStack(spacing: 25) {
                            HomeButton(title: "Estatus de insulina", image: "insulina", destination: InsulinaView())
                            HomeButton(title: "Recetas", image: "recetas", destination: RecetasView())
                        }
                        HStack(spacing: 25) {
                            HomeButton(title: "Dieta", image: "dieta", destination: DietaIA())
                            
                            HomeButton(title: "Aprende +", image: "aprende", destination: AprendeView())
                        }

                        // Botón de Alarmas
                        Button(action: { mostrarAlarmaSheet.toggle() }) {
                            ZStack {
                                HStack {
                                    Image("alarma")
                                        .resizable()
                                        .frame(width: 45, height: 45)
                                    Spacer()
                                    Image(systemName: "plus")
                                        .font(.title)
                                        .foregroundColor(.secondary) // adaptativo
                                }
                                Text("Alarmas")
                                    .font(.title2)
                                    .fontWeight(.bold)
                                    .foregroundColor(Color("aqua"))
                            }
                            .padding()
                            .frame(height: 70)
                            .background(Color("cielo"))
                            .cornerRadius(25)
                            .shadow(color: Color.black.opacity(colorScheme == .light ? 0.3 : 0),
                                    radius: 5, x: 2, y: 2)
                        }
                        .sheet(isPresented: $mostrarAlarmaSheet) {
                            CrearAlarmaView { nueva in
                                alarmas.append(nueva)
                                programarNotificacion(alarma: nueva)
                            }
                        }
                        .padding(.top, 8)

                        // Lista de Alarmas
                        ForEach(alarmas) { alarma in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text("\(alarma.hora, formatter: horaFormatter)")
                                        .font(.headline)
                                        .foregroundColor(.primary)
                                    Text(alarma.descripcion)
                                        .font(.subheadline)
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                                Button(action: { eliminarAlarma(alarma) }) {
                                    Image(systemName: "trash")
                                        .foregroundColor(.red)
                                }
                            }
                            .padding()
                            .background(Color(.systemBackground))
                            .cornerRadius(12)
                            .shadow(color: Color.black.opacity(colorScheme == .light ? 0.1 : 0),
                                    radius: 3, x: 0, y: 1)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 40)

                    Spacer()
                }
            }
            .navigationBarHidden(true)
        }
    }

    func eliminarAlarma(_ alarma: Alarma) {
        alarmas.removeAll { $0.id == alarma.id }
        UNUserNotificationCenter.current()
            .removePendingNotificationRequests(withIdentifiers: [alarma.id.uuidString])
    }

    func programarNotificacion(alarma: Alarma) {
        let contenido = UNMutableNotificationContent()
        contenido.title = "⏰ Alarma"
        contenido.body = alarma.descripcion.isEmpty ? "¡Es hora!" : alarma.descripcion
        contenido.sound = .default

        let calendar = Calendar.current
        let componentes = calendar.dateComponents([.hour, .minute], from: alarma.hora)
        var fecha = DateComponents()
        fecha.hour = componentes.hour
        fecha.minute = componentes.minute

        let trigger = UNCalendarNotificationTrigger(dateMatching: fecha, repeats: false)
        let request = UNNotificationRequest(identifier: alarma.id.uuidString,
                                            content: contenido,
                                            trigger: trigger)

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Error al programar la notificación: \(error)")
            } else {
                print("🔔 Notificación programada a las \(fecha.hour!):\(fecha.minute!)")
            }
        }
    }

    var horaFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter
    }
}

struct CrearAlarmaView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var horaAlarma = Date()
    @State private var descripcion = ""

    var onGuardar: (Alarma) -> Void

    var body: some View {
        NavigationView {
            VStack(spacing: 25) {
                Text("Nueva alarma")
                    .font(.title)
                    .fontWeight(.bold)
                    .padding(.top)

                DatePicker("", selection: $horaAlarma, displayedComponents: .hourAndMinute)
                    .datePickerStyle(.wheel)
                    .labelsHidden()
                    .padding()

                TextField("Descripción", text: $descripcion)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)

                Button {
                    let nueva = Alarma(hora: horaAlarma, descripcion: descripcion)
                    onGuardar(nueva)
                    dismiss()
                } label: {
                    Text("Guardar")
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color("aqua"))
                        .cornerRadius(12)
                }
                .padding(.horizontal)

                Button("Cancelar") { dismiss() }
                    .foregroundColor(.red)
                    .padding()

                Spacer()
            }
            .padding()
            .navigationBarHidden(true)
        }
    }
}

struct HomeButton<Destination: View>: View {
    let title: String
    let image: String
    let destination: Destination

    var body: some View {
        NavigationLink(destination: destination) {
            VStack(spacing: 10) {
                Image(image)
                    .resizable()
                    .frame(width: 85, height: 85)
                Text(title)
                    .font(.headline)
                    .fontWeight(.semibold)
                    .multilineTextAlignment(.center)
                    .foregroundColor(Color("aqua"))
                    .lineLimit(2)
                    .minimumScaleFactor(0.7)
            }
            .padding()
            .frame(width: 160, height: 150)
            .background(Color("cielo"))
            .cornerRadius(25)
            .shadow(color: .gray.opacity(0.3), radius: 5, x: 2, y: 2)
        }
    }
}

#Preview {
    HomeView()
}
