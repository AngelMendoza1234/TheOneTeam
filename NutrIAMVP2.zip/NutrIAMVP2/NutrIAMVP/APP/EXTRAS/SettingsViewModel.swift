//
//  SettingsViewModel.swift
//  NutrIA
//
//  Created by Samuel Alarcón on 07/06/25.
//


import SwiftUI

class SettingsViewModel: ObservableObject {
    @AppStorage("appTheme") var appTheme: AppTheme = .light
    @AppStorage("appLanguage") var appLanguage: Language = .english
}
