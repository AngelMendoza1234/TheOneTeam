//
//  UploadView.swift
//  NutrIA
//
//  Created by Samuel Alarcón on 07/06/25.
//


import SwiftUI
import PhotosUI

struct UploadView: View {
    @ObservedObject var settings: SettingsViewModel
    @State private var selectedItem: PhotosPickerItem? = nil
    
    var body: some View {
        NavigationView {
            VStack {
                
            }
            .navigationTitle(settings.appLanguage == .english ? "Note" : "Publicar")
        }
    }
}

#Preview {
    UploadView(settings: SettingsViewModel())
}
