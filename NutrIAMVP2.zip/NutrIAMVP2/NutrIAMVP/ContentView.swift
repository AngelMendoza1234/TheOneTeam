import SwiftUI

struct ContentView: View {
    // Persistimos si el usuario ya pasó por el flujo inicial
    @AppStorage("hasUserInfo") private var hasUserInfo = false

    var body: some View {
        NavigationStack {
            if hasUserInfo {
                // Ya tenemos info → vamos a la MainView
                MainView()
            } else {
                // Aún no → mostramos EligeDieta
                EligeDieta(hasUserInfo: $hasUserInfo)
            }
        }
    }
}

#Preview {
    ContentView()
}
