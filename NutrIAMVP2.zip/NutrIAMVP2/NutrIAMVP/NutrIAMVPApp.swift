//
//  NutrIAMVPApp.swift
//  NutrIAMVP
//
//  Created by Samuel Alarcón on 08/06/25.
//

import SwiftUI

@main
struct NutrIAMVPApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
